/* ═══════════════════════════════════════════════════════════════════
   Numerical Differentiation Calculator — script.js
   Methods: Forward Difference | Backward Difference | Central Difference
═══════════════════════════════════════════════════════════════════ */

/* ── STATE ───────────────────────────────────────────────────────── */
let tableData      = [];
let currentMethod  = 'forward';

const defaultData  = [
  { x: 1.0, y: 2.7183  },
  { x: 1.5, y: 4.4817  },
  { x: 2.0, y: 7.3891  },
  { x: 2.5, y: 12.1825 },
  { x: 3.0, y: 20.0855 },
];

/* ── NAVIGATION ──────────────────────────────────────────────────── */
function navTo(hash, btn) {
  document.querySelector(hash).scrollIntoView({ behavior: 'smooth' });
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

/* ── TABLE RENDERING ─────────────────────────────────────────────── */
function renderTable() {
  // Always keep data sorted by x
  tableData.sort((a, b) => a.x - b.x);

  const tbody = document.getElementById('table-body');
  tbody.innerHTML = '';

  tableData.forEach((row, i) => {
    const hVal = i < tableData.length - 1
      ? (tableData[i + 1].x - row.x).toFixed(4)
      : '&mdash;';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="idx-c">${i}</td>
      <td>
        <input class="data-inp" type="number" step="any"
          value="${row.x}"
          onchange="updateCell(${i}, 'x', this.value)" />
      </td>
      <td>
        <input class="data-inp" type="number" step="any"
          value="${row.y}"
          onchange="updateCell(${i}, 'y', this.value)" />
      </td>
      <td class="h-c">${hVal}</td>
      <td>
        <button class="del-btn" onclick="deleteRow(${i})" title="Remove row">&#10005;</button>
      </td>`;
    tbody.appendChild(tr);
  });

  document.getElementById('row-count').textContent = tableData.length + ' rows';
}

function updateCell(i, key, val) {
  tableData[i][key] = parseFloat(val) || 0;
  renderTable();
}

function addRow() {
  const last = tableData[tableData.length - 1];
  const step = tableData.length > 1
    ? tableData[tableData.length - 1].x - tableData[tableData.length - 2].x
    : 0.5;
  tableData.push({ x: last ? +(last.x + step).toFixed(4) : 0, y: 0 });
  renderTable();
}

function deleteRow(i) {
  if (tableData.length <= 2) {
    showErr('data-err', 'A minimum of two data points is required.');
    return;
  }
  tableData.splice(i, 1);
  renderTable();
}

function resetData() {
  tableData = defaultData.map(r => ({ ...r }));
  renderTable();
  document.getElementById('results-section').classList.remove('show');
  document.getElementById('results-empty').style.display = 'block';
  document.getElementById('steps-box').classList.remove('show');
}

/* ── CONTROL HANDLERS ────────────────────────────────────────────── */
function onModeChange() {
  const isSingle = document.getElementById('calc-mode').value === 'single';
  document.getElementById('x0-field').style.display = isSingle ? 'block' : 'none';
}

function onHChange() {
  const isManual = document.getElementById('h-mode').value === 'manual';
  document.getElementById('h-manual-field').style.display = isManual ? 'block' : 'none';
}

function setMethod(m) {
  currentMethod = m;
  ['fw', 'bw', 'cn', 'all'].forEach(k => {
    document.getElementById('mb-' + k).className = 'm-btn';
  });
  const map = { forward: 'fw', backward: 'bw', central: 'cn', all: 'all' };
  document.getElementById('mb-' + map[m]).className = 'm-btn sel-' + map[m];
}

/* ── ERROR DISPLAY ───────────────────────────────────────────────── */
function showErr(id, msg) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 5000);
}

/* ── NUMERICAL METHODS ───────────────────────────────────────────── */

/**
 * Determine the step size h for index i.
 * Uses manual value if selected, otherwise reads from sorted data.
 */
function getH(data, i) {
  if (document.getElementById('h-mode').value === 'manual') {
    const v = parseFloat(document.getElementById('h-inp').value);
    return (isNaN(v) || v === 0) ? null : v;
  }
  if (i < data.length - 1) return data[i + 1].x - data[i].x;
  if (i > 0)               return data[i].x - data[i - 1].x;
  return null;
}

/**
 * Forward Difference: dy/dx ≈ [f(x₀+h) − f(x₀)] / h
 */
function fwdDiff(data, i) {
  if (i >= data.length - 1) return null;
  const h = getH(data, i);
  if (!h) return null;
  return (data[i + 1].y - data[i].y) / h;
}

/**
 * Backward Difference: dy/dx ≈ [f(x) − f(x−h)] / h
 */
function bwdDiff(data, i) {
  if (i <= 0) return null;
  const h = getH(data, i);
  if (!h) return null;
  return (data[i].y - data[i - 1].y) / h;
}

/**
 * Central Difference: f′(x) = [f(x+h) − f(x−h)] / 2h
 */
function cenDiff(data, i) {
  if (i <= 0 || i >= data.length - 1) return null;
  if (document.getElementById('h-mode').value === 'manual') {
    const h = parseFloat(document.getElementById('h-inp').value);
    if (!h) return null;
    return (data[i + 1].y - data[i - 1].y) / (2 * h);
  }
  return (data[i + 1].y - data[i - 1].y) / (data[i + 1].x - data[i - 1].x);
}

/** Round to d decimal places, returns null if value is null/NaN */
function fmt(v, d = 6) {
  return (v === null || isNaN(v)) ? null : parseFloat(v.toFixed(d));
}

/* ── MAIN CALCULATE ENTRY POINT ──────────────────────────────────── */
function calculate() {
  const data = [...tableData].sort((a, b) => a.x - b.x);

  if (data.length < 2) {
    showErr('calc-err', 'At least two data points are required.');
    return;
  }
  for (const r of data) {
    if (isNaN(r.x) || isNaN(r.y)) {
      showErr('calc-err', 'All x and y values must be valid numbers.');
      return;
    }
  }

  if (document.getElementById('calc-mode').value === 'single') {
    calcSingle(data);
  } else {
    calcAll(data);
  }
}

/* ── SINGLE POINT MODE ───────────────────────────────────────────── */
function calcSingle(data) {
  const x0 = parseFloat(document.getElementById('x0-inp').value);
  if (isNaN(x0)) {
    showErr('calc-err', 'Please enter a valid x\u2080 value.');
    return;
  }

  // Find nearest data index to x0
  let idx = 0, minD = Infinity;
  data.forEach((r, i) => {
    const d = Math.abs(r.x - x0);
    if (d < minD) { minD = d; idx = i; }
  });

  const methods = currentMethod === 'all'
    ? ['forward', 'backward', 'central']
    : [currentMethod];

  let html = `
    <div class="step-line">
      Point of differentiation: <strong>x\u2080 = ${x0}</strong>
      &rarr; nearest data index <strong>i = ${idx}</strong>
      &nbsp;(x = ${data[idx].x}, y = ${data[idx].y})
    </div><br>`;

  // Hide results table while showing steps
  document.getElementById('results-section').classList.remove('show');
  document.getElementById('results-empty').style.display = 'block';

  methods.forEach(m => {

    if (m === 'forward') {
      if (idx >= data.length - 1) {
        html += `<div class="step-line" style="opacity:.5">Forward difference: not applicable at the final data point.</div><br>`;
        return;
      }
      const h   = getH(data, idx) || (data[idx + 1].x - data[idx].x);
      const res = (data[idx + 1].y - data[idx].y) / h;
      html += `
        <div class="step-line fw-c">&#9658; Forward Difference</div>
        <div class="step-line">h = <strong>${h.toFixed(4)}</strong></div>
        <div class="step-line">f(x\u2080 + h) = <strong>${data[idx + 1].y}</strong>, &nbsp; f(x\u2080) = <strong>${data[idx].y}</strong></div>
        <div class="step-line">dy/dx = (${data[idx + 1].y} &minus; ${data[idx].y}) / ${h.toFixed(4)}</div>
        <div class="step-line result-line fw-c">&there4; &nbsp; dy/dx &asymp; <strong>${res.toFixed(6)}</strong></div><br>`;
    }

    if (m === 'backward') {
      if (idx <= 0) {
        html += `<div class="step-line" style="opacity:.5">Backward difference: not applicable at the first data point.</div><br>`;
        return;
      }
      const h   = getH(data, idx) || (data[idx].x - data[idx - 1].x);
      const res = (data[idx].y - data[idx - 1].y) / h;
      html += `
        <div class="step-line bw-c">&#9668; Backward Difference</div>
        <div class="step-line">h = <strong>${h.toFixed(4)}</strong></div>
        <div class="step-line">f(x) = <strong>${data[idx].y}</strong>, &nbsp; f(x &minus; h) = <strong>${data[idx - 1].y}</strong></div>
        <div class="step-line">dy/dx = (${data[idx].y} &minus; ${data[idx - 1].y}) / ${h.toFixed(4)}</div>
        <div class="step-line result-line bw-c">&there4; &nbsp; dy/dx &asymp; <strong>${res.toFixed(6)}</strong></div><br>`;
    }

    if (m === 'central') {
      if (idx <= 0 || idx >= data.length - 1) {
        html += `<div class="step-line" style="opacity:.5">Central difference: requires data points on both sides.</div><br>`;
        return;
      }
      let twoH;
      if (document.getElementById('h-mode').value === 'manual') {
        twoH = 2 * parseFloat(document.getElementById('h-inp').value);
      } else {
        twoH = data[idx + 1].x - data[idx - 1].x;
      }
      const res = (data[idx + 1].y - data[idx - 1].y) / twoH;
      html += `
        <div class="step-line cn-c">&#9670; Central Difference</div>
        <div class="step-line">2h = <strong>${twoH.toFixed(4)}</strong></div>
        <div class="step-line">f(x + h) = <strong>${data[idx + 1].y}</strong>, &nbsp; f(x &minus; h) = <strong>${data[idx - 1].y}</strong></div>
        <div class="step-line">f&prime;(x) = (${data[idx + 1].y} &minus; ${data[idx - 1].y}) / ${twoH.toFixed(4)}</div>
        <div class="step-line result-line cn-c">&there4; &nbsp; f&prime;(x) = <strong>${res.toFixed(6)}</strong></div><br>`;
    }
  });

  document.getElementById('steps-content').innerHTML = html;
  document.getElementById('steps-box').classList.add('show');
  document.getElementById('steps-box').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/* ── ALL POINTS MODE ─────────────────────────────────────────────── */
function calcAll(data) {
  document.getElementById('steps-box').classList.remove('show');

  const m      = currentMethod;
  const showFw = m === 'all' || m === 'forward';
  const showBw = m === 'all' || m === 'backward';
  const showCn = m === 'all' || m === 'central';

  /* Build header row */
  const thead = document.getElementById('result-thead');
  const headerRow = document.createElement('tr');
  const cols = ['i', 'x', 'y = f(x)', 'h'];
  if (showFw) cols.push('Forward dy/dx');
  if (showBw) cols.push('Backward dy/dx');
  if (showCn) cols.push("Central f'(x)");

  cols.forEach(label => {
    const th = document.createElement('th');
    th.textContent = label;
    if (label.includes('Forward'))  th.className = 'fw-th';
    if (label.includes('Backward')) th.className = 'bw-th';
    if (label.includes('Central'))  th.className = 'cn-th';
    headerRow.appendChild(th);
  });
  thead.innerHTML = '';
  thead.appendChild(headerRow);

  /* Build data rows */
  const tbody = document.getElementById('result-tbody');
  tbody.innerHTML = '';

  data.forEach((row, i) => {
    const h = i < data.length - 1
      ? (data[i + 1].x - row.x).toFixed(4)
      : i > 0 ? (row.x - data[i - 1].x).toFixed(4) : '—';

    const fw = fmt(fwdDiff(data, i));
    const bw = fmt(bwdDiff(data, i));
    const cn = fmt(cenDiff(data, i));

    const cell = (v, cls) => v === null
      ? `<td><span class="c-na">n/a</span></td>`
      : `<td class="${cls}">${v}</td>`;

    const tr = document.createElement('tr');
    let inner = `
      <td class="c-i">${i}</td>
      <td class="c-x">${row.x}</td>
      <td class="c-y">${row.y}</td>
      <td class="c-h">${h}</td>`;

    if (showFw) inner += cell(fw, 'c-fw');
    if (showBw) inner += cell(bw, 'c-bw');
    if (showCn) inner += cell(cn, 'c-cn');

    tr.innerHTML = inner;
    tbody.appendChild(tr);
  });

  /* Badge label */
  const labels = {
    forward:  '&#9658; Forward',
    backward: '&#9668; Backward',
    central:  '&#9670; Central',
    all:      '&#9658; Forward &nbsp;&middot;&nbsp; &#9668; Backward &nbsp;&middot;&nbsp; &#9670; Central',
  };
  document.getElementById('result-badge').innerHTML = labels[m];

  /* Show results */
  document.getElementById('results-section').classList.add('show');
  document.getElementById('results-empty').style.display = 'none';
  document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
}

/* ── INIT ────────────────────────────────────────────────────────── */
tableData = defaultData.map(r => ({ ...r }));
renderTable();
