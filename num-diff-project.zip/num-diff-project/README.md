# Numerical Differentiation Calculator

A classy, elegant web calculator for numerical differentiation using three classical finite-difference methods.

## Methods Implemented

| Method | Formula | Accuracy |
|--------|---------|----------|
| **Forward Difference** | `dy/dx ≈ [f(x₀+h) − f(x₀)] / h` | First-order |
| **Backward Difference** | `dy/dx ≈ [f(x) − f(x−h)] / h` | First-order |
| **Central Difference** | `f′(x) = [f(x+h) − f(x−h)] / 2h` | Second-order |

## Features

- 📊 **Editable dataset** — add, edit, or delete (x, y) data points
- 🔢 **All Points mode** — compute derivatives for the entire table at once
- 🎯 **Single Point mode** — differentiate at a specific x₀ with step-by-step workings
- ⚙️ **Flexible h** — auto-computed from data or set manually
- 🎨 **Classy UI** — warm parchment tones, Cormorant Garamond & Cinzel typography

## Project Structure

```
num-diff-project/
├── index.html       ← Page structure & markup
├── style.css        ← All styles & design tokens
├── script.js        ← Numerical logic & interactivity
├── netlify.toml     ← Netlify deployment config
└── README.md        ← This file
```

## Deploy to Netlify

### Option A — Drag & Drop (Easiest)
1. Go to [app.netlify.com](https://app.netlify.com)
2. Log in and click **"Add new site"** → **"Deploy manually"**
3. Drag the entire `num-diff-project` folder onto the deploy area
4. Your site is live instantly ✅

### Option B — Netlify CLI
```bash
npm install -g netlify-cli
cd num-diff-project
netlify deploy --prod
```

### Option C — GitHub Integration
1. Push this folder to a GitHub repository
2. In Netlify: **"Add new site"** → **"Import from Git"**
3. Select your repo — publish directory should be `.` (root)
4. Click **Deploy** ✅

## Local Development

No build step required — pure HTML/CSS/JS.

```bash
# Using Python
python -m http.server 8080

# Using Node
npx serve .
```

Then open `http://localhost:8080` in your browser.
